<instructions>
This file powers chat suggestion chips. Keep it focused and actionable.

# Be proactive
- Suggest ideas and things the user might want to add *soon*. 
- Important things the user might be overlooking (SEO, more features, bug fixes). 
- Look specifically for bugs and edge cases the user might be missing (e.g., what if no user has logged in).

# Rules
- Each task must be wrapped in a "<todo id="todo-id">" and "</todo>" tag pair.
- Inside each <todo> block:
  - First line: title (required)
  - Second line: description (optional)
- The id must be a short stable identifier for the task and must not change when you rewrite the title or description.
- You should proactively review this file after each response, even if the user did not explicitly ask, maintain it if there were meaningful changes (new requirement, task completion, reprioritization, or stale task cleanup).
- Think BIG: suggest ambitious features, UX improvements, technical enhancements, and creative possibilities.
- Balance quick wins with transformative ideas — include both incremental improvements and bold new features.
- Aim for 3-5 high-impact tasks that would genuinely excite the user.
- Tasks should be specific enough to act on, but visionary enough to inspire.
- Remove or rewrite stale tasks when completed, obsolete, or clearly lower-priority than current work.
- Re-rank by impact and user value, not just urgency.
- Draw inspiration from the project's existing features — what would make them 10x better?
- Don't be afraid to suggest features the user hasn't explicitly mentioned.
</instructions>

<!-- Add tasks here only when there are real next steps. -->

<todo id="otp-step">
Add OTP / 2FA verification step
After the phone step, add a 6-digit one-time-password input to simulate SMS verification.
</todo>

<todo id="loading-skeleton">
Add loading skeleton for bank grid
Show shimmer placeholders while logos are loading to improve perceived performance.
</todo>

<todo id="mobile-responsive">
Polish mobile layout
Ensure the bank tile grid and form fields feel native on small screens (max-width 375px).
</todo>

<todo id="success-redirect">
Post-success callback / redirect
After the final step, fire a configurable onSuccess callback or redirect to a confirmation URL.
</todo>
