export { QuoteCard } from "./QuoteCard";
