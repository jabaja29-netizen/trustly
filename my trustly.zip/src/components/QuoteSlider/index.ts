export { QuoteSlider } from "./QuoteSlider";
